# s-w-systems
Repository for s/w systems assignment.
Author: Harshal Purohit (MT2024056)
