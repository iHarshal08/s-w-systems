/*
===========================================================================================================================
Name : 7.c
Author : Harshal Purohit
Description : Write a program to copy file1 into file2 ($cp file1 file2).
Date: 28th Aug, 2024.
===========================================================================================================================
*/


#include <stdlib.h>
int main() {
    system("cp src.txt dest.txt");
    return 0;
}
